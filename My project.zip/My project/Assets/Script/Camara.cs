using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camara : MonoBehaviour
{
    public Transform[] puntos;
    public int indice;
    public float vel;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        transform.position = Vector3.Lerp(transform.position, puntos[indice].position, vel * Time.deltaTime);
        if (Input.GetKeyDown(KeyCode.A))
        {
            Anterior();
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            Siguiente();
        }


    }

    public void Siguiente()
    {
        indice++;
        indice = Mathf.Clamp(indice, 0, puntos.Length - 1);
    }

    public void Anterior()
    {
        indice--;
        indice = Mathf.Clamp(indice, 0, puntos.Length - 1);
    }
}
